from flask_app import app

app.run(host="0.0.0.0", debug=True)
