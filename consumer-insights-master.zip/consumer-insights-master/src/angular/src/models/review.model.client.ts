export class Review{
  "customer_id": string;
  "helpful_votes": string;
  "marketplace": string;
  "product_id": string;
  "product_parent": string;
  "product_title": string;
  "review_body": string;
  "review_date": string;
  "review_headline": string;
  "review_id": string;
  "star_rating": string;
  "total_votes": string;
  "verified_purchase": string;
  "vine": string;
  "year": string;
}
