# README /test

This directory holds developmental code for spark and airflow related processes. Before having the final versions ready, 
they were incrementally developed. This also allowed me to experiment with technologies and tools
that I have not worked with before.